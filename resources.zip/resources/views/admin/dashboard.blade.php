@extends('layouts.admin')
@section('title')
  Dashboard | Sistem Pendukung Keputusan Bantuan Rumah Tidak Layak Huni
@endsection
@section('content')
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="btn-group pull-right">
                <ol class="breadcrumb hide-phone p-0 m-0">
                    <li class="breadcrumb-item"><a href="#">SPK-RTLH</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
            <h4 class="page-title">Selamat datang, {{ auth()->user()->name }} !</h4>
        </div>
    </div>
</div>
<!-- end page title end breadcrumb -->


<div class="row">
<div  class="col-lg-12 col-md-6 text-center">
    <p></p>
    <img src="{{ asset('/rtlh.png') }}" alt="rtlh" width="200px">
    <h1 class="mt-2 text-dark">PANEL ADMIN</h1>
    <h2 class="text-dark">SISTEM PENDUKUNG KEPUTUSAN PENERIMAAN BANTUAN RUMAH TIDAK LAYAK HUNI</h2>
</div>
</div>



<!-- end row -->

@endsection
