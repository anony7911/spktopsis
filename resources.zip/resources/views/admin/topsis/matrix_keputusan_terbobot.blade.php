@extends('layouts.admin')
@section('title')
    Matrix Keputusan Terbobot| SPK Bantuan RTLH
@endsection
@section('content')
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Matrix Keputusan</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>no_kk</th>
                    <th>nama_lengkap</th>
                    <th>dinding(c1)</th>
                    <th>atap(c2)</th>
                    <th>lantai(c3)</th>
                    <th>fmck(c4)</th>
                    <th>luas_lantai(c5)</th>
                    <th>penghasilan(c6)</th>
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


@endsection
@push('scripts')
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#table-rtlh").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '{!! route('admin.topsis.matrix_keputusan_terbobot') !!}',
                    order:[0,'desc'],
                    columns:[
                        {data:null, render:function(data,type,row,meta){
                        return meta.settings._iDisplayStart+meta.row+1;
                        },orderable:false},
                        {data:'no_kk',name :'no_kk'},
                        {data:'nama_lengkap', name: 'nama_lengkap'},
                        {data:'v_dinding',name:'v_dinding'},
                        {data:'v_atap',name:'v_atap'},
                        {data:'v_lantai',name:'v_lantai'},
                        {data:'v_fmck',name:'v_fmck'},
                        {data:'v_luas_lantai',name:'v_luas_lantai'},
                        {data:'v_penghasilan',name:'v_penghasilan'}                        
                    ]
                });
            } );

        </script>
        @include("admin.script.form-modal-ajax")
@endpush