@extends('layouts.admin')
@section('title')
    Data RTLH | SPK Bantuan Rumah Tinggal Layak Huni
@endsection
@section('content')
<br>
<div class="row">
    <div class="col-12">
        <div class="card-box">

            <h4 class="header-title m-t-0">Perbaharui Data</h4>

        </div>
    </div><!-- end col -->
</div>
<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Data Rumah Tinggal Layak Huni</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>
            <form class="form-horizontal" action="{{route('admin.rtlh.update')}}" method="POST">
                <div class="form-group">
                    <label>nama_lengkap</label>
                    <input name="nama_lengkap" class="form-control" value="{{$rtlhs->nama_lengkap}}" />
                </div>
            </form>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


@endsection