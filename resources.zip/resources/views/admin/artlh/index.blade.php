@extends('layouts.admin')
@section('title')
    Data RTLH | Sistem Pendukung Keputusan Bantuan Rumah Tidak Layak Huni
@endsection
@section('content')
<br>
<div class="row">
    <div class="col-12">
        <div class="card-box">

            <h4 class="header-title m-t-0 ">Tambah Data</h4>

            @include('admin.artlh.add')
            @include('admin.artlh.edit')


            <div class="button-list">
                <!-- Custom width modal -->
                <button type="button" class="btn btn-info waves-light waves-effect w-md" data-toggle="modal" data-target="#tambah-rtlh" data-table="#tabel-user"><i class="mdi mdi-library-plus"></i> Tambah Data</button>
            </div>
        </div>
    </div><!-- end col -->
</div>
<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Data Rumah Tidak Layak Huni</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table  table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>no_kk</th>
                    <th>nama_lengkap</th>
                    <th>tanggal_lahir</th>
                    <th>jenis_kelamin</th>
                    <th>pendidikan</th>
                    <th>dinding</th>
                    <th>atap</th>
                    <th>lantai</th>
                    <th>fmck</th>
                    <th>luas_lantai</th>
                    <th>penghasilan</th>
                    <th>Aksi</th>                                            
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


@endsection
@push('scripts')
        <script type="text/javascript">
            

            function editRtlh(trigerer){
                     var tabel = $(trigerer).parent().data('table-target');
                     var modal = $(trigerer).data('target');
                     var tr =$(trigerer).parent().parent().parent();
                     data = $("table#"+tabel).DataTable().row(tr).data();
                     var form = modal+" form ";
                     $(form+"input#no_kk").val(data.no_kk);
                     $(form+"input#nama_lengkap").val(data.nama_lengkap);
                     $(form+"input#tanggal_lahir").val(data.tanggal_lahir);
                     $(form+"input#jenis_kelamin").val(data.jenis_kelamin);
                     $(form+"input#pendidikan").val(data.pendidikan);
                     $(form+"input#dinding").val(data.dinding);
                     $(form+"input#atap").val(data.atap);
                     $(form+"input#lantai").val(data.lantai);
                     $(form+"input#fmck").val(data.fmck);
                     $(form+"input#luas_lantai").val(data.luas_lantai);
                     $(form+"input#penghasilan").val(data.penghasilan);
                     $(form+"input#id").val(data.id);
                 }
            $(document).ready(function() {
                $("#table-rtlh").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '{!! route('admin.rtlh.index') !!}',                                                                                    
                    order:[0,'desc'],
                    columns:[
                        {data:null, render:function(data,type,row,meta){
                            return meta.settings._iDisplayStart+meta.row+1;
                        },orderable:false},
                        {data:'no_kk',name :'no_kk'},
                        {data:'nama_lengkap', name: 'nama_lengkap'},
                        {data:'tanggal_lahir',name:'tanggal_lahir'},
                        {data:'jenis_kelamin',name:'jenis_kelamin'},
                        {data:'pendidikan',name:'pendidikan'},
                        {data:'dinding',render:function(data,type,row){
                            if(row.dinding == 1){
                                return 'Bambu';
                            }else if(row.dinding == 2){
                                return 'Tripleks';
                            }else if(row.dinding == 3){
                                return 'Papan';
                            }else if(row.dinding == 4){
                                return 'Bambu';
                            }else{
                                return 'Tidak Ada';
                            }
                        }},
                        {data:'atap',render:function(data,type,row){
                            if(row.atap == 1){
                                return 'Genteng';
                            }else if(row.atap == 2){
                                return 'Seng';
                            }else if(row.atap == 3){
                                return 'Sirap';
                            }else if(row.atap == 4){
                                return 'Rumbia';
                            }else{
                                return 'Tidak Ada';
                            }
                        }},
                        {data:'lantai',render:function(data,type,row){
                            if(row.lantai == 1){
                                return 'Keramik';
                            }else if(row.lantai == 2){
                                return 'Semen';
                            }else if(row.lantai == 3){
                                return 'Papan';
                            }else if(row.lantai == 4){
                                return 'Tanah';
                            }else{
                                return 'Tidak Ada';
                            }
                        }},
                        {data:'fmck', render:function(data, type, row){
                            if(row.fmck == 1){
                            return 'Memiliki';
                            }else if(row.fmck == 2){
                            return 'Tidak Memiliki';
                            }else{
                            return 'Tidak Ada';
                            }
                        }},
                        {data:'luas_lantai',render:function(data, type, row) {
                            if(row.luas_lantai == 1){
                            return 'Lebih dari 32 Meter Persegi';
                            }else if(row.luas_lantai == 2){
                            return '24 - 32 Meter Persegi';
                            }else if(row.luas_lantai == 3){
                            return '16 - 24 Meter Persegi';
                            }else if(row.luas_lantai == 4){
                            return 'Kurang dari 16 Meter Persegi';
                            }else{
                            return 'Tidak Ada';
                            }
                        }},
                        {data:'penghasilan',render:function(data, type, row){
                            if(row.penghasilan == 1){
                            return 'Lebih dari 2.000.000,-';
                            }else if(row.penghasilan == 2){
                            return '1.500.000,- s.d 2.000.000,-';
                            }else if(row.penghasilan == 3){
                            return '1.000.000,- s.d 1.500.000,-';
                            }else if(row.penghasilan == 4){
                            return 'Kurang dari 1.000.000,-';
                            }else{
                            return 'Tidak Ada';
                            }
                        }},
                        {data:'aksi',name: 'aksi',searchable:false,orderable: false}       
                    ]
                });
            } );

        </script>
        @include("admin.script.form-modal-ajax")
@endpush