@extends('layouts.admin')
@section('title')
Penerima RTLH | Sistem Pendukung Keputusan Bantuan Rumah Tidak Layak Huni
@endsection
@section('content')
<br>
<div class="row">
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title"><b>Data Rumah Tidak Layak Huni</b></h4>
                <p class="text-muted font-14 m-b-30">

                </p>

                <table id="table-rtlh" class="table  table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>no_kk</th>
                            <th>nama_lengkap</th>
                            <th>tanggal_lahir</th>
                            <th>jenis_kelamin</th>
                            <th>pendidikan</th>
                            <th>dinding</th>
                            <th>atap</th>
                            <th>lantai</th>
                            <th>fmck</th>
                            <th>luas_lantai</th>
                            <th>penghasilan</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        $no = 1;
                        @endphp
                        @forelse ($penerimas as $penerima)
                        <tr>
                            <td>{{ $no++ }}</td>
                            <td>{{ $penerima->no_kk }}</td>
                            <td>{{ $penerima->nama_lengkap }}</td>
                            <td>{{ $penerima->tanggal_lahir }}</td>
                            <td>{{ $penerima->jenis_kelamin }}</td>
                            <td>{{ $penerima->pendidikan }}</td>
                            <td>
                                @if($penerima->dinding == 4)
                                Bambu
                                @elseif($penerima->dinding == 3)
                                Tripleks
                                @elseif($penerima->dinding == 2){
                                Papan
                                }
                                @elseif($penerima->dinding == 1)
                                Batu Bata
                                @endif
                            </td>
                            <td>
                                @if($penerima->atap == 4)
                                Rumbia
                                @elseif($penerima->atap == 3)
                                Sirap
                                @elseif($penerima->atap == 2){
                                Seng
                                }
                                @elseif($penerima->atap == 1)
                                Genteng
                                @endif
                            </td>
                            <td>
                                @if($penerima->lantai == 4)
                                Tanah
                                @elseif($penerima->lantai == 3)
                                Papan
                                @elseif($penerima->lantai == 2){
                                Semen
                                }
                                @elseif($penerima->lantai == 1)
                                Keramik
                                @endif
                            </td>
                            <td>
                                @if($penerima->fmck == 2)
                                Tidak Memiliki
                                @elseif($penerima->fmck == 1)
                                Memiliki
                                @endif
                            </td>
                            <td>
                                @if($penerima->luas_lantai == 4)
                                Kurang dari 16 Meter Persegi
                                @elseif($penerima->luas_lantai == 3)
                                16 - 24 Meter Persegi
                                @elseif($penerima->luas_lantai == 2){
                                24 - 32 Meter Persegi
                                }
                                @elseif($penerima->luas_lantai == 1)
                                Lebih dari 32 Meter Persegi
                                @endif
                            </td>
                            <td>
                                @if($penerima->lantai == 4)
                                Kurang dari 1.000.000,-
                                @elseif($penerima->lantai == 3)
                                1.000.000,- s.d 1.500.000,-
                                @elseif($penerima->lantai == 2){
                                1.500.000,- s.d 2.000.000,-
                                }
                                @elseif($penerima->lantai == 1)
                                Lebih dari 2.000.000,-
                                @endif
                            </td>
                        </tr>

                        @empty
                        <tr>
                            <td colspan="10" class="text-center">Tidak ada data.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
    <!-- end row -->


    @endsection
