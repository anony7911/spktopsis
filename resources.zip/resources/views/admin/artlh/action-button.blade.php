<div class="button-list" data-id="{{$id}}" data-table-target="table-rtlh">
    <button type="button" class="btn btn-icon waves-effect waves-light btn-warning" data-toggle="modal" data-target="#editrtlh" onclick="return editRtlh(this);"><i class="fa fa-wrench"></i></button>
    <button data-url="{{route('admin.rtlh.delete')}}" class="btn btn-icon waves-effect waves-light btn-danger" onclick="hapusData(this);"> <i class="fa fa-remove"></i> </button>
    {{-- <button data-url="{{route('admin.rtlh.softDetele')}}" class="btn btn-icon waves-effect waves-light btn-danger" onclick="hapusData(this);"> <i class="fa fa-remove"></i> </button> --}}

</div>
