@extends('layouts.admin')
@section('title')
    Admin Page
@endsection
@section('content')

@endsection
