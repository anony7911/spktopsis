<?php $__env->startSection('title'); ?>
    Matrix Keputusan | SIMAPRES
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Matrix Keputusan</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-ksm" class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>NIK PJ</th>
                    <th>Nama PJ</th>
                    <th>Nama KSM</th>
                    <th>Capital (C1)</th>
                    <th>Condition (C2)</th>
                    <th>Character (C3)</th>
                    <th>Capacity (C4)</th>
                    <th>Collateral (C5)</th>
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#table-ksm").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.topsis.matrix_keputusan'); ?>',
                    order:[0,'desc'],
                    columns:[
                        {data:'id', name: 'id'},
                        {data:'nik',name :'nik'},
                        {data:'nama', name: 'nama'},
                        {data:'nama_ksm',name:'nama_ksm'},
                        {data:'l_capital',name:'l_capital'},
                        {data:'l_condition',name:'l_condition'},
                        {data:'l_character',name:'l_character'},
                        {data:'l_capacity',name:'l_capacity'},
                        {data:'l_collateral',name:'l_collateral'}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\simapres-m\simapres-master\resources\views/admin/topsis/matrix_keputusan.blade.php ENDPATH**/ ?>