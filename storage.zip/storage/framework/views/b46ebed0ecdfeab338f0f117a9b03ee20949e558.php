<div id="navigation">
    <!-- Navigation Menu-->
    <ul class="navigation-menu">

        <li class="has-submenu">
            <a href="/"><i class="fi-air-play"></i>Dashboard</a>
        </li>
        
        <li class="has-submenu">
            <a href="/rtlh/ahasil_rekomendasi"><i class="fa fa-trophy"></i>Hasil Rekomendasi</a>
        </li>

    </ul>
    
    <!-- End navigation menu -->
</div> <!-- end #navigation --><?php /**PATH D:\xampp\htdocs\spk_topsis_rtlh\resources\views/koord/koord-nav.blade.php ENDPATH**/ ?>