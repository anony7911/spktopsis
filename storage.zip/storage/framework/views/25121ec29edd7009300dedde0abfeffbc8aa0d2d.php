<!-- Signup modal content -->
<div id="tambah-rtlh" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <h2 class=" text-center m-b-30">
                    Tambah Data RTLH
                </h2>

                <form id="tambah-rtlh" data-table-target="table-rtlh"  class="form-horizontal" action="<?php echo e(route('admin.rtlh.add')); ?>" method="POST">
                <fieldset id="fieldset">
                    <div class="form-group m-b-25">
                        <div class="col-12" id="message">
                            
                        </div>
                    </div>

                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">no_kk</label>
                            <input class="form-control" name="no_kk" type="text" id="no_kk" required="" >
                        </div>
                    </div>

                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">nama_lengkap</label>
                            <input class="form-control" name="nama_lengkap" type="text" id="nama_lengkap" required="">
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">tanggal_lahir</label>
                            <input class="form-control" name="tanggal_lahir" type="date" id="tanggal_lahir" required="">
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">jenis_kelamin</label>
                            <select name="jenis_kelamin" id="" class="form-control">
                                <option value="">-- Pilih --</option>
                                <option value="Laki-Laki">Laki-laki</option>
                                <option value="Perempuan">Perempuan</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">pendidikan</label>
                            <select name="pendidikan" id="" class="form-control">
                                <option value="">-- Pilih --</option>
                                <option value="S2/S3">S2/S3</option>
                                <option value="D3/D4/S1">D3/D4/S1</option>
                                <option value="SMA/SMK">SMA/SMK Sederajat</option>
                                <option value="SMP/MTs">SMP/MTs Sedejarat</option>
                                <option value="SD/MIN">SD/MIN Sederajat</option>
                                <option value="Tidak-Tamat-SD">Tidak Tamat SD</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">dinding</label>
                            <select name="dinding" id="" class="form-control">
                                <option value="">-- Pilih --</option>
                                <option value="4">Bambu</option>
                                <option value="3">Tripleks</option>
                                <option value="2">Papan</option>
                                <option value="1">Batu Bata</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">atap</label>
                            <select name="atap" id="" class="form-control">
                                <option value="">-- Pilih --</option>
                                <option value="4">Rumbia</option>
                                <option value="3">Sirap</option>
                                <option value="2">Seng</option>
                                <option value="1">Genteng</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">lantai</label>
                                <select name="lantai" id="" class="form-control">
                                    <option value="">-- Pilih --</option>
                                    <option value="4">Tanah</option>
                                    <option value="3">Papan</option>
                                    <option value="2">Semen</option>
                                    <option value="1">Keramik</option>
                                </select>
                            </div>
                    </div>
                    <div class="form-group m-b-25">
                                <div class="col-12">
                                    <label for="">fmck</label>
                                    <select name="fmck" id="" class="form-control">
                                        <option value="">-- Pilih --</option>
                                        <option value="2">Tidak Memiliki</option>
                                        <option value="1">Memiliki</option>
                                    </select>
                                </div>
                    </div>
                    <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">luas_lantai</label>
                                    <select name="luas_lantai" id="" class="form-control">
                                        <option value="">-- Pilih --</option>
                                        <option value="4"> Kurang dari 16 Meter Persegi </option>
                                        <option value="3">16 - 24 Meter Persegi</option>
                                        <option value="2">24 - 32 Meter Persegi</option>
                                        <option value="1">Lebih dari 32 Meter Persegi</option>
                                    </select>
                            </div>
                    </div>
                    <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">penghasilan</label>
                                    <select name="penghasilan" id="" class="form-control">
                                        <option value="">-- Pilih --</option>
                                        <option value="4">Kurang dari 1.000.000,-</option>
                                        <option value="3">1.000.000,- s.d 1.500.000,-</option>
                                        <option value="2">1.500.000,- s.d 2.000.000,-</option>
                                        <option value="1">Lebih dari 2.000.000,-</option>
                                    </select>
                            </div>
                    </div>
                    <div class="form-group account-btn text-center m-t-10">
                        <div class="col-12">
                            <button class="btn w-lg btn-rounded btn-primary waves-effect waves-light" type="submit">Tambah</button>
                        </div>
                    </div>
                </fieldset>
                </form>

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/artlh/add.blade.php ENDPATH**/ ?>