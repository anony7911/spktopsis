<?php $__env->startSection('title'); ?>
    Matrix Solusi Ideal Positif Negatif| SPK Bantuan RTLH
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Matrix Solusi Ideal Positif Negatif</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table table-bordered">
                <thead>
                <tr>
                    <th>Atribut</th>
                    <th>dinding(c1)</th>
                    <th>atap(c2)</th>
                    <th>lantai(c3)</th>
                    <th>fmck(c4)</th>
                    <th>luas_lantai(c5)</th>
                    <th>penghasilan(c6)</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><b>Positif</b></td>
                        <td><?php echo e($solusi['c1']['positif']); ?> </td>
                        <td><?php echo e($solusi['c2']['positif']); ?></td>
                        <td><?php echo e($solusi['c3']['positif']); ?></td>
                        <td><?php echo e($solusi['c4']['positif']); ?></td>
                        <td><?php echo e($solusi['c5']['positif']); ?></td>
                        <td><?php echo e($solusi['c6']['positif']); ?></td>
                    </tr>
                    <tr>
                        <td><b>Negatif</b></td>
                        <td><?php echo e($solusi['c1']['negatif']); ?></td>
                        <td><?php echo e($solusi['c2']['negatif']); ?></td>
                        <td><?php echo e($solusi['c3']['negatif']); ?></td>
                        <td><?php echo e($solusi['c4']['negatif']); ?></td>
                        <td><?php echo e($solusi['c5']['negatif']); ?></td>
                        <td><?php echo e($solusi['c6']['negatif']); ?></td>
                    </tr>
                </tbody>



                <tbody>
                </tbody>
            </table>

        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            


        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/topsis/matrix_solusi_ideal.blade.php ENDPATH**/ ?>