<?php $__env->startSection('title'); ?>
  Dashboard | Admin Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="btn-group pull-right">
                <ol class="breadcrumb hide-phone p-0 m-0">
                    <li class="breadcrumb-item"><a href="#">SPK-RTLH</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
            
        </div>
    </div>
</div>
<!-- end page title end breadcrumb -->


<div class="row">
<div  class="col-lg-12 col-md-6 text-center">
    <p></p>
    <img src="<?php echo e(asset('/rtlh.png')); ?>" alt="rtlh" width="200px">
    <h1 class="mt-2 text-dark">SELAMAT DATANG</h1>
    <h2 class="text-dark">DI SISTEM PENDUKUNG KEPUTUSAN PENERIMAAN BANTUAN RTLH</h2>
</div>
    
</div>



<!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('koord.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/koord/dashboard.blade.php ENDPATH**/ ?>