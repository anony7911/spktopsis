<div class="button-list" data-id="<?php echo e($id); ?>" data-table-target="table-rtlh">
    
    <button data-url="<?php echo e(route('admin.rtlh.delete')); ?>" class="btn btn-icon waves-effect waves-light btn-danger" onclick="hapusData(this);"> <i class="fa fa-remove"></i> </button>
</div><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/artlh/action-button.blade.php ENDPATH**/ ?>