<?php $__env->startSection('title'); ?>
    Jarak Solusi Positif | SIMAPRES
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Jarak Solusi Positif</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-ksm" class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Lengkap</th>
                    <th>Nama KSM</th>
                    <th>Capital (C1)</th>
                    <th>Condition (C2)</th>
                    <th>Character (C3)</th>
                    <th>Capacity (C4)</th>
                    <th>Collateral (C5)</th>
                    <th>Total</th>
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#table-ksm").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.topsis.jarak_solusi_positif'); ?>',
                    order:[0,'desc'],
                    columns:[
                        {data:'id', name: 'id'},
                        {data:'nama', name: 'nama'},
                        {data:'nama_ksm', name: 'nama_ksm'},
                        {data:'a_capital',name:'a_prestasi'},
                        {data:'a_condition',name:'a_condition'},
                        {data:'a_character',name:'a_character'},
                        {data:'a_capacity',name:'a_capacity'},
                        {data:'a_collateral',name:'a_collateral'},
                        {data:'a_total',name:'a_total'}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\simapres-m\simapres-master\resources\views/admin/topsis/jarak_solusi_positif.blade.php ENDPATH**/ ?>