<?php $__env->startSection('title'); ?>
    Nilai Preferensi | SPK Bantuan RTLH
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Nilai Preferensi</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>no_kk</th>
                    <th>nama_lengkap</th>
                    <th>dinding(c1)</th>
                    <th>atap(c2)</th>
                    <th>lantai(c3)</th>
                    <th>fmck(c4)</th>
                    <th>luas_lantai(c5)</th>
                    <th>penghasilan(c6)</th>
                    <th>Nilai Preferensi</th>
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#table-rtlh").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.topsis.nilai_preferensi'); ?>',
                    order:[0,'asc'],
                    columns:[
                        {data:'id', name: 'id'},
                        {data:'no_kk', name: 'no_kk'},
                        {data:'nama_lengkap', name: 'nama_lengkap'},
                        {data:'a_dinding',name:'a_dinding'},
                        {data:'a_atap',name:'a_atap'},
                        {data:'a_lantai',name:'a_lantai'},
                        {data:'a_fmck',name:'a_fmck'},
                        {data:'a_luas_lantai',name:'a_luas_lantai'},                        
                        {data:'a_penghasilan',name:'a_penghasilan'},
                        {data:'nilai_preferensi',name:'nilai_preferensi'}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/topsis/nilai_preferensi.blade.php ENDPATH**/ ?>