<?php $__env->startSection('title'); ?>
  Dashboard | Admin Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="page-title-box">
            <div class="btn-group pull-right">
                <ol class="breadcrumb hide-phone p-0 m-0">
                    <li class="breadcrumb-item"><a href="#">SPK-DBKSM</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </div>
            <h4 class="page-title">Welcome !</h4>
        </div>
    </div>
</div>
<!-- end page title end breadcrumb -->


<div class="row">
    <div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card-box tilebox-one">
            <h6 class="text-muted text-uppercase mb-3">KSM Kamboja</h6>
            <h4 class="mb-3" data-plugin="counterup"><?php echo e($ksm1); ?> </h4>
        </div>
    </div>

    <div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card-box tilebox-one">
            <h6 class="text-muted text-uppercase mb-3">KSM Mekar</h6>
            <h4 class="mb-3"><?php echo e($ksm2); ?> </span></h4>
        </div>
    </div>

    <div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card-box tilebox-one">
            <h6 class="text-muted text-uppercase mb-3">KSM Melati</h6>
            <h4 class="mb-3"><?php echo e($ksm3); ?> </h4>

        </div>
    </div>

    <div class="col-xs-12 col-md-6 col-lg-6 col-xl-3">
        <div class="card-box tilebox-one">
            <h6 class="text-muted text-uppercase mb-3">KSM Merdeka</h6>
            <h4 class="mb-3" data-plugin="counterup"><?php echo e($ksm4); ?> </h4>
        </div>
    </div>

    <h4>Total: <?php echo e($ksm); ?> KSM </h4>
</div>



<!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\simapres-m\simapres-master\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>