<?php $__env->startSection('title'); ?>
    Data RTLH | Sistem Pendukung Keputusan Bantuan Rumah Tidak Layak Huni
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="col-12">
        <div class="card-box">

            <h4 class="header-title m-t-0 ">Tambah Data</h4>

            <?php echo $__env->make('admin.artlh.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('admin.artlh.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="button-list">
                <!-- Custom width modal -->
                <button type="button" class="btn btn-info waves-light waves-effect w-md" data-toggle="modal" data-target="#tambah-rtlh" data-table="#tabel-user"><i class="mdi mdi-library-plus"></i> Tambah Data</button>
            </div>
        </div>
    </div><!-- end col -->
</div>
<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Data Rumah Tidak Layak Huni</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table  table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>no_kk</th>
                    <th>nama_lengkap</th>
                    <th>tanggal_lahir</th>
                    <th>jenis_kelamin</th>
                    <th>pendidikan</th>
                    <th>dinding</th>
                    <th>atap</th>
                    <th>lantai</th>
                    <th>fmck</th>
                    <th>luas_lantai</th>
                    <th>penghasilan</th>
                    <th>Aksi</th>                                            
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            

            function editRtlh(trigerer){
                     var tabel = $(trigerer).parent().data('table-target');
                     var modal = $(trigerer).data('target');
                     var tr =$(trigerer).parent().parent().parent();
                     data = $("table#"+tabel).DataTable().row(tr).data();
                     var form = modal+" form ";
                     $(form+"input#no_kk").val(data.no_kk);
                     $(form+"input#nama_lengkap").val(data.nama_lengkap);
                     $(form+"input#tanggal_lahir").val(data.tanggal_lahir);
                     $(form+"input#jenis_kelamin").val(data.jenis_kelamin);
                     $(form+"input#pendidikan").val(data.pendidikan);
                     $(form+"input#dinding").val(data.dinding);
                     $(form+"input#atap").val(data.atap);
                     $(form+"input#lantai").val(data.lantai);
                     $(form+"input#fmck").val(data.fmck);
                     $(form+"input#luas_lantai").val(data.luas_lantai);
                     $(form+"input#penghasilan").val(data.penghasilan);
                     $(form+"input#id").val(data.id);
                 }
            $(document).ready(function() {
                $("#table-rtlh").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.rtlh.index'); ?>',                                                                                    
                    order:[0,'desc'],
                    columns:[
                        {data:'id', name: 'id'},
                        {data:'no_kk',name :'no_kk'},
                        {data:'nama_lengkap', name: 'nama_lengkap'},
                        {data:'tanggal_lahir',name:'tanggal_lahir'},
                        {data:'jenis_kelamin',name:'jenis_kelamin'},
                        {data:'pendidikan',name:'pendidikan'},
                        {data:'dinding',name:'dinding'},
                        {data:'atap',name:'atap'},
                        {data:'lantai',name:'lantai'},
                        {data:'fmck',name:'fmck'},
                        {data:'luas_lantai',name:'luas_lantai'},
                        {data:'penghasilan',name:'penghasilan'},
                        {data:'aksi',name: 'aksi',searchable:false,orderable: false}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\spk_topsis_rtlh\resources\views/admin/artlh/index.blade.php ENDPATH**/ ?>