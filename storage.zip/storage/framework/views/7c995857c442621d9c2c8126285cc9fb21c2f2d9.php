<!-- Signup modal content -->
<div id="tambah-ksm" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <h2 class=" text-center m-b-30">
                    Tambah ksm
                </h2>

                <form id="tambah-ksm" data-table-target="table-ksm"  class="form-horizontal" action="<?php echo e(route('admin.ksm.add')); ?>" method="POST">
                <fieldset id="fieldset">
                    <div class="form-group m-b-25">
                        <div class="col-12" id="message">
                            
                        </div>
                    </div>

                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">Nama PJ</label>
                            <input class="form-control" name="nama" type="text" id="name" required="" placeholder="Nama Penanggungjawab">
                        </div>
                    </div>

                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">NIK</label>
                            <input class="form-control" name="nik" type="text" id="nik" required="" placeholder="NIM">
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">Nama KSM</label>
                            <input class="form-control" name="nama_ksm" type="text" id="nama_ksm" required="" placeholder="nama ksm">
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">capital</label>
                            <select name="capital" id="" class="form-control">
                                <option value="3">Modal Baru</option>
                                <option value="2">Modal Lama</option>
                                <option value="1">Lainnya</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                        <div class="col-12">
                            <label for="">condition</label>
                            <select name="condition" id="" class="form-control">
                                <option value="3">1x Pinjaman</option>
                                <option value="2">2x Pinjaman</option>
                                <option value="1">Lainnya</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">character</label>
                                <select name="character" id="" class="form-control">
                                    <option value="3">5-6 Orang, 30% Perempuan</option>
                                    <option value="2">7 Orang, 30% Perempuan</option>
                                    <option value="1">Lainnya</option>
                                </select>
                            </div>
                    </div>
                    <div class="form-group m-b-25">
                                <div class="col-12">
                                    <label for="">capacity</label>
                                    <select name="capacity" id="" class="form-control">
                                        <option value="3">10 Bulan</option>
                                        <option value="2">12 Bulan</option>
                                        <option value="1">18 Bulan</option>
                                    </select>
                                </div>
                    </div>
                    <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">collateral</label>
                                    <select name="collateral" id="" class="form-control">
                                        <option value="3">Barang Jaminan</option>
                                        <option value="2">Sertifikat</option>
                                        <option value="1">Lainnya</option>
                                    </select>
                            </div>
                    </div>
                    <div class="form-group account-btn text-center m-t-10">
                        <div class="col-12">
                            <button class="btn w-lg btn-rounded btn-primary waves-effect waves-light" type="submit">Tambah</button>
                        </div>
                    </div>
                </fieldset>
                </form>

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/aksm/add.blade.php ENDPATH**/ ?>