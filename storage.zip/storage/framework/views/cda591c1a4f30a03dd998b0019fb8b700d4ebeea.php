<div id="navigation">
    <!-- Navigation Menu-->
    <ul class="navigation-menu">

        <li class="has-submenu">
            <a href="/"><i class="fi-air-play"></i>Dashboard</a>
        </li>
        
        <li class="has-submenu">
            <a href="/koord/ahasil_rekomendasi"><i class="fa fa-trophy"></i>Hasil Rekomendasi</a>
        </li>

    </ul>
    
    <!-- End navigation menu -->
</div> <!-- end #navigation --><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/koord/koord-nav.blade.php ENDPATH**/ ?>