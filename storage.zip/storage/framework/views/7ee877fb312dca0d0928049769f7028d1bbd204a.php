<!-- Signup modal content -->
<div id="editrtlh" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel"
    aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <h2 class="text-uppercase text-center m-b-30">
                </h2>

                <form id="edit-rtlh" data-table-target="table-rtlh" class="form-horizontal"
                    action="<?php echo e(route('admin.rtlh.update')); ?>" method="POST">
                    <fieldset id="fieldset">
                        <div class="form-group m-b-25">
                            <div class="col-12" id="message">

                            </div>
                        </div>

                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">no_kk</label>
                                <input class="form-control" name="id" type="hidden" id="id" required="">
                                <input class="form-control" name="no_kk" type="text" id="no_kk" required="">
                            </div>
                        </div>

                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">nama_lengkap</label>
                                <input class="form-control" name="nama_lengkap" type="text" id="nama_lengkap"
                                    required="">
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">tanggal_lahir</label>
                                <input class="form-control" name="tanggal_lahir" type="date" id="tanggal_lahir"
                                    required="">
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">jenis_kelamin</label>
                                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                                    <option value="Laki-Laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">pendidikan</label>
                                <select name="pendidikan" id="pendidikan" class="form-control">
                                    <option value="SMP/MTs">SMP/MTs Sedejarat</option>
                                    <option value="SMA/SMK">SMA/SMK Sederajat</option>
                                    <option value="SD/MIN">SD/MIN Sederajat</option>
                                    <option value="Tidak-Tamat-SD">Tidak Tamat SD</option>
                                    <option value="S2/S3">S2/S3</option>
                                    <option value="D3/D4/S1">D3/D4/S1</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">dinding</label>
                                <select name="dinding" id="dinding" class="form-control">
                                    <option value="4">Bambu</option>
                                    <option value="3">Tripleks</option>
                                    <option value="2">Papan</option>
                                    <option value="1">Batu Bata</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">atap</label>
                                <select name="atap" id="atap" class="form-control">
                                    <option value="4">Rumbia</option>
                                    <option value="3">Sirap</option>
                                    <option value="2">Seng</option>
                                    <option value="1">Genteng</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">lantai</label>
                                <select name="lantai" id="lantai" class="form-control">
                                    <option value="4">Tanah</option>
                                    <option value="3">Papan</option>
                                    <option value="2">Semen</option>
                                    <option value="1">Keramik</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">fmck</label>
                                <select name="fmck" id="fmck" class="form-control">
                                    <option value="2">Tidak Memiliki</option>
                                    <option value="1">Memiliki</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">luas_lantai</label>
                                <select name="luas_lantai" id="luas_lantai" class="form-control">
                                    <option value="4"> Kurang dari 16 Meter Persegi </option>
                                    <option value="3">16 - 24 Meter Persegi</option>
                                    <option value="2">24 - 32 Meter Persegi</option>
                                    <option value="1">Lebih dari 32 Meter Persegi</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group m-b-25">
                            <div class="col-12">
                                <label for="">penghasilan</label>
                                <select name="penghasilan" id="penghasilan" class="form-control">
                                    <option value="4">Kurang dari 1.000.000,-</option>
                                    <option value="3">1.000.000,- s.d 1.500.000,-</option>
                                    <option value="2">1.500.000,- s.d 2.000.000,-</option>
                                    <option value="1">Lebih dari 2.000.000,-</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group account-btn text-center m-t-10">
                            <div class="col-12">
                                <button class="btn w-lg btn-rounded btn-primary waves-effect waves-light"
                                    type="submit">Perbaharui</button>
                            </div>
                        </div>
                    </fieldset>
                </form>

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --><?php /**PATH D:\Laravel 5.8\spk_topsis_rtlh\resources\views/admin/artlh/edit.blade.php ENDPATH**/ ?>