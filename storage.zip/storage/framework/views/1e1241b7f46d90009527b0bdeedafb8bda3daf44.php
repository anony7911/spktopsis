<?php $__env->startSection('title'); ?>
    Data KSM | SPK-DB-KSM
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="col-12">
        <div class="card-box">

            <h4 class="header-title m-t-0">Tambah Data</h4>

            <?php echo $__env->make('admin.aksm.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            


            <div class="button-list">
                <!-- Custom width modal -->
                <button type="button" class="btn btn-info waves-light waves-effect w-md" data-toggle="modal" data-target="#tambah-ksm" data-table="#tabel-user"><i class="mdi mdi-library-plus"></i> Tambah Data</button>
            </div>
        </div>
    </div><!-- end col -->
</div>
<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Data KSM</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-ksm" class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>NIK PJ</th>
                    <th>Nama PJ</th>
                    <th>nama_ksm</th>
                    <th>capital</th>
                    <th>character</th>
                    <th>condition</th>
                    <th>capacity</th>
                    <th>collateral</th>
                    <th>Aksi</th>                                            
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            

            $(document).ready(function() {
                $("#table-ksm").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.ksm.index'); ?>',                                                                                    
                    order:[0,'desc'],
                    columns:[
                        {data:'id', name: 'id'},
                        {data:'nik',name :'nik'},
                        {data:'nama', name: 'nama'},
                        {data:'nama_ksm',name:'nama_ksm'},
                        {data:'capital',name:'capital'},
                        {data:'character',name:'character'},
                        {data:'condition',name:'condition'},
                        {data:'capacity',name:'capacity'},
                        {data:'collateral',name:'collateral'},
                        {data:'aksi',name: 'aksi',searchable:false,orderable: false}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/aksm/index.blade.php ENDPATH**/ ?>