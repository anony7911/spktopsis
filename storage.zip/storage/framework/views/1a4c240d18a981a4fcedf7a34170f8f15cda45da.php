<div class="button-list" data-id="<?php echo e($id); ?>" data-table-target="table-ksm">
    
    <button data-url="<?php echo e(route('admin.ksm.delete')); ?>" class="btn btn-icon waves-effect waves-light btn-danger" onclick="hapusData(this);"> <i class="fa fa-remove"></i> </button>
</div><?php /**PATH D:\laravel8\topsis\spk_topsis_rtlh\resources\views/admin/aksm/action-button.blade.php ENDPATH**/ ?>