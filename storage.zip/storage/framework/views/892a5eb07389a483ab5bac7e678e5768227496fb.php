<?php $__env->startSection('title'); ?>
Penerima RTLH | Sistem Pendukung Keputusan Bantuan Rumah Tidak Layak Huni
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row">
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title"><b>Data Rumah Tidak Layak Huni</b></h4>
                <p class="text-muted font-14 m-b-30">

                </p>

                <table id="table-rtlh" class="table  table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>no_kk</th>
                            <th>nama_lengkap</th>
                            <th>tanggal_lahir</th>
                            <th>jenis_kelamin</th>
                            <th>pendidikan</th>
                            <th>dinding</th>
                            <th>atap</th>
                            <th>lantai</th>
                            <th>fmck</th>
                            <th>luas_lantai</th>
                            <th>penghasilan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $penerimas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penerima): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($penerima->no_kk); ?></td>
                            <td><?php echo e($penerima->nama_lengkap); ?></td>
                            <td><?php echo e($penerima->tanggal_lahir); ?></td>
                            <td><?php echo e($penerima->jenis_kelamin); ?></td>
                            <td><?php echo e($penerima->pendidikan); ?></td>
                            <td>
                                <?php if($penerima->dinding == 4): ?>
                                Bambu
                                <?php elseif($penerima->dinding == 3): ?>
                                Tripleks
                                <?php elseif($penerima->dinding == 2): ?>{
                                Papan
                                }
                                <?php elseif($penerima->dinding == 1): ?>
                                Batu Bata
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($penerima->atap == 4): ?>
                                Rumbia
                                <?php elseif($penerima->atap == 3): ?>
                                Sirap
                                <?php elseif($penerima->atap == 2): ?>{
                                Seng
                                }
                                <?php elseif($penerima->atap == 1): ?>
                                Genteng
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($penerima->lantai == 4): ?>
                                Tanah
                                <?php elseif($penerima->lantai == 3): ?>
                                Papan
                                <?php elseif($penerima->lantai == 2): ?>{
                                Semen
                                }
                                <?php elseif($penerima->lantai == 1): ?>
                                Keramik
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($penerima->fmck == 2): ?>
                                Tidak Memiliki
                                <?php elseif($penerima->fmck == 1): ?>
                                Memiliki
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($penerima->luas_lantai == 4): ?>
                                Kurang dari 16 Meter Persegi
                                <?php elseif($penerima->luas_lantai == 3): ?>
                                16 - 24 Meter Persegi
                                <?php elseif($penerima->luas_lantai == 2): ?>{
                                24 - 32 Meter Persegi
                                }
                                <?php elseif($penerima->luas_lantai == 1): ?>
                                Lebih dari 32 Meter Persegi
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($penerima->lantai == 4): ?>
                                Kurang dari 1.000.000,-
                                <?php elseif($penerima->lantai == 3): ?>
                                1.000.000,- s.d 1.500.000,-
                                <?php elseif($penerima->lantai == 2): ?>{
                                1.500.000,- s.d 2.000.000,-
                                }
                                <?php elseif($penerima->lantai == 1): ?>
                                Lebih dari 2.000.000,-
                                <?php endif; ?>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center">Tidak ada data.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
    <!-- end row -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel 5.8\spk_topsis_rtlh\resources\views/admin/artlh/penerima.blade.php ENDPATH**/ ?>