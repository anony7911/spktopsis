<?php $__env->startSection('title'); ?>
    Matrix Keputusan | SPK Bantuan RTLH
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Matrix Keputusan</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>no_kk</th>
                    <th>nama_lengkap</th>
                    <th>dinding(c1)</th>
                    <th>atap(c2)</th>
                    <th>lantai(c3)</th>
                    <th>fmck(c4)</th>
                    <th>luas_lantai(c5)</th>
                    <th>penghasilan(c6)</th>
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#table-rtlh").DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('admin.topsis.matrix_keputusan'); ?>',
                    order:[0,'asc'],
                    columns:[
                        {data:null, render:function(data,type,row,meta){
                        return meta.settings._iDisplayStart+meta.row+1;
                        },orderable:false},
                        {data:'no_kk',name :'no_kk'},
                        {data:'nama_lengkap', name: 'nama_lengkap'},
                        {data:'l_dinding',name:'l_dinding'},
                        {data:'l_atap',name:'l_atap'},
                        {data:'l_lantai',name:'l_lantai'},
                        {data:'l_fmck',name:'l_fmck'},
                        {data:'l_luas_lantai',name:'l_luas_lantai'},                        
                        {data:'l_penghasilan',name:'l_penghasilan'}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel 5.8\spk_topsis_rtlh\resources\views/admin/topsis/matrix_keputusan.blade.php ENDPATH**/ ?>