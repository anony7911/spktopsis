<?php $__env->startSection('title'); ?>
    Hasil Rekomendasi | Sistem Pendukung Keputusan Bantuan Rumah Tidak Layak 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>

<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title"><b>Hasil Rekomendasi</b></h4>
            <p class="text-muted font-14 m-b-30">
            
            </p>

            <table id="table-rtlh" class="table table-bordered">
                <thead>
                <tr>
                    <th>Rangking</th>
                    <th>no_kk</th>
                    <th>nama_lengkap</th>
                    <th>dinding(c1)</th>
                    <th>atap(c2)</th>
                    <th>lantai(c3)</th>
                    <th>fmck(c4)</th>
                    <th>luas_lantai(c5)</th>
                    <th>penghasilan(c6)</th>
                    <th>Nilai Preferensi</th>
                </tr>
                </thead>


                <tbody>
                </tbody>
            </table>
            <div class="font-weight-bold px-5">
                <span>
                    <h5>Kategori:</h5>
                    <h5>* Warna Hijau: Layak</h5>
                    <h5>* Warna Merah: Tidak Layak</h5>
                </span>
            </div>
        </div>
    </div>
</div> <!-- end row -->
<!-- end row -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            
            $(document).ready(function() {
                $("#table-rtlh").DataTable({
                    processing: true,
                    serverSide: true,
                    paging: true,
                    limit: 1,
                    ajax: '<?php echo route('koord.nilai_preferensi'); ?>',
                    order:[9,'desc'],
                    
                    columns:[
                        {data:null, render: function(data, type, row, meta) {
                            return meta.row + meta.settings._iDisplayStart + 1;
                        },orderable:false},
                        {data:'no_kk', name: 'no_kk',orderable:false},
                        {data:'nama_lengkap', name: 'nama_lengkap',orderable:false},
                        {data:'dinding',name:'dinding',orderable:false, visible:false},
                        {data:'atap',name:'atap',orderable:false, visible:false},
                        {data:'lantai',name:'lantai',orderable:false, visible:false},
                        {data:'fmck',name:'fmck',orderable:false, visible:false},
                        {data:'luas_lantai',name:'luas_lantai',orderable:false, visible:false},
                        {data:'penghasilan',name:'penghasilan',orderable:false, visible:false},
                        {data:'nilai_preferensi',name:'nilai_preferensi'}                        
                    ]
                });
            } );

        </script>
        <?php echo $__env->make("admin.script.form-modal-ajax", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('koord.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\spk_topsis_rtlh\resources\views/koord/hasil_rekomendasi.blade.php ENDPATH**/ ?>